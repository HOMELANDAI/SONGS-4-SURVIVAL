# Project Overview

## Project Name
**Songs 4 Survival by HAI**

## Secondary Concept
**Desert Island Draft: Keeps & Cuts - Anthem Edition**

## One-Line Pitch
A live music survival game where contestants cut massive song lists down to their true musical DNA while viewers predict, vote, earn XP, unlock HAI badges, and compete on live leaderboards.

## What Makes It Different
This is not a normal music trivia game. It is a music identity contest. The audience watches people reveal who they are through the songs they refuse to cut.

The format combines music debate, emotional confessionals, live ranking pressure, audience prediction, data visualization, collectible digital badges, tropical venue spectacle, livestream-native interaction, and potential AR venue layers.

## Core Entertainment Value
Music is universal and emotionally charged. Viewers understand the pressure instantly: if you could only keep 15 songs, what would survive?

That question creates debate, loyalty, nostalgia, pride, embarrassment, vulnerability, and surprise.

## Primary User Groups

### Contestants
People who curate and defend their music identity through timed cutdown rounds.

### Online Viewers
Livestream viewers who predict outcomes, earn points, unlock badges, and compete on leaderboards.

### In-Venue Viewers
Guests at a tropical live venue who participate through phones, QR codes, AR voting panels, and live crowd energy.

### Hosts / Producers
The show team that manages rounds, reveals, confessionals, overlays, and audience engagement.

## Content Pillars

1. The Cut - emotional elimination of songs.
2. The Defense - contestants explain why a song survived or was cut.
3. The Secret 10 - private favorites drive the dramatic reveal.
4. The Prediction Game - viewers compete to guess outcomes.
5. The Data - genre, decade, mood, artist loyalty, overlap, and ranking analytics.
6. The Venue - tropical pavilion, tiki lights, beach bar, electronic boards, AR overlays, and HAI branding.
