-- Seed data for Songs 4 Survival by HAI

insert into public.events (name, subtitle, status)
values ('Songs 4 Survival by HAI', 'Every cut tells a story.', 'prototype');

insert into public.songs (title, artist, genre, decade, mood)
values
('Purple Rain', 'Prince', 'Pop/Rock', '80s', 'anthem'),
('Billie Jean', 'Michael Jackson', 'Pop', '80s', 'dance'),
('Love', 'Musiq Soulchild', 'R&B', '2000s', 'romantic'),
('New York, New York', 'Frank Sinatra', 'Standards', '70s', 'classic'),
('Could You Be Loved', 'Bob Marley', 'Reggae', '80s', 'uplift'),
('Sweet Caroline', 'Neil Diamond', 'Pop', '60s', 'singalong'),
('Bohemian Rhapsody', 'Queen', 'Rock', '70s', 'epic'),
('Hey Ya!', 'Outkast', 'Hip-Hop/Pop', '2000s', 'party');

insert into public.badges (name, description, rarity, xp_reward)
values
('Ranking Master', 'Predict the exact Secret 10 order.', 'legendary', 50),
('Top 3 Oracle', 'Correctly predict a contestant top 3.', 'epic', 25),
('#1 Prophet', 'Correctly predict a contestant number one song.', 'epic', 20),
('Era Whisperer', 'Correctly predict the decade of a number one song.', 'rare', 10),
('Crossover King', 'Identify crossover songs between contestants.', 'rare', 15),
('Crossover Queen', 'Identify crossover songs between contestants.', 'rare', 15),
('Surprise Factor Sleuth', 'Correctly call classic, deep cut, or guilty pleasure.', 'rare', 10),
('Survival Streak', 'Build a streak of correct predictions.', 'common', 5),
('Cutdown Champ', 'Win a live round leaderboard.', 'legendary', 40),
('Secret 10 Oracle', 'Identify all Secret 10 songs.', 'legendary', 35),
('Deep Cut Detective', 'Correctly predict a deep cut survivor.', 'epic', 20),
('Guilty Pleasure Prophet', 'Correctly predict a guilty pleasure favorite.', 'epic', 20);
