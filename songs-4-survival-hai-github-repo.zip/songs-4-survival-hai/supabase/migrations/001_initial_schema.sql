-- Songs 4 Survival by HAI - Initial Supabase schema
create extension if not exists "uuid-ossp";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  avatar_url text,
  xp integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  subtitle text,
  status text not null default 'draft',
  starts_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.contestants (
  id uuid primary key default uuid_generate_v4(),
  event_id uuid references public.events(id) on delete cascade,
  name text not null,
  avatar_url text,
  bio text,
  current_round text,
  created_at timestamptz not null default now()
);

create table if not exists public.songs (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  artist text,
  genre text,
  decade text,
  mood text,
  created_at timestamptz not null default now()
);

create table if not exists public.game_rounds (
  id uuid primary key default uuid_generate_v4(),
  event_id uuid references public.events(id) on delete cascade,
  name text not null,
  from_count integer,
  to_count integer,
  starts_at timestamptz,
  locks_at timestamptz,
  reveal_at timestamptz,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists public.contestant_song_selections (
  id uuid primary key default uuid_generate_v4(),
  contestant_id uuid references public.contestants(id) on delete cascade,
  song_id uuid references public.songs(id) on delete cascade,
  round_id uuid references public.game_rounds(id) on delete cascade,
  status text not null default 'active',
  is_secret_highlight boolean not null default false,
  secret_rank integer,
  created_at timestamptz not null default now(),
  unique (contestant_id, song_id, round_id)
);

create table if not exists public.predictions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.profiles(id) on delete cascade,
  event_id uuid references public.events(id) on delete cascade,
  contestant_id uuid references public.contestants(id) on delete cascade,
  round_id uuid references public.game_rounds(id) on delete cascade,
  prediction_type text not null,
  selected_song_ids uuid[] default '{}',
  ranking_order uuid[] default '{}',
  predicted_era text,
  predicted_surprise_factor text,
  locked boolean not null default false,
  locked_at timestamptz,
  points_awarded integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.badges (
  id uuid primary key default uuid_generate_v4(),
  name text not null unique,
  description text,
  rarity text not null default 'common',
  icon_url text,
  unlock_condition text,
  xp_reward integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.user_badges (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.profiles(id) on delete cascade,
  badge_id uuid references public.badges(id) on delete cascade,
  event_id uuid references public.events(id) on delete set null,
  earned_at timestamptz not null default now(),
  unique (user_id, badge_id, event_id)
);

create table if not exists public.leaderboard_snapshots (
  id uuid primary key default uuid_generate_v4(),
  event_id uuid references public.events(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  rank integer,
  xp integer not null default 0,
  correct_predictions integer not null default 0,
  badge_count integer not null default 0,
  streak integer not null default 0,
  snapshot_at timestamptz not null default now()
);

create table if not exists public.confessional_clips (
  id uuid primary key default uuid_generate_v4(),
  event_id uuid references public.events(id) on delete cascade,
  contestant_id uuid references public.contestants(id) on delete cascade,
  round_id uuid references public.game_rounds(id) on delete cascade,
  title text not null,
  clip_url text,
  quote text,
  emotion_tag text,
  created_at timestamptz not null default now()
);

create table if not exists public.ar_venue_anchors (
  id uuid primary key default uuid_generate_v4(),
  event_id uuid references public.events(id) on delete cascade,
  name text not null,
  anchor_type text not null,
  description text,
  position_json jsonb,
  content_json jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.events enable row level security;
alter table public.contestants enable row level security;
alter table public.songs enable row level security;
alter table public.game_rounds enable row level security;
alter table public.contestant_song_selections enable row level security;
alter table public.predictions enable row level security;
alter table public.badges enable row level security;
alter table public.user_badges enable row level security;
alter table public.leaderboard_snapshots enable row level security;
alter table public.confessional_clips enable row level security;
alter table public.ar_venue_anchors enable row level security;

create policy "Public can read events" on public.events for select using (true);
create policy "Public can read contestants" on public.contestants for select using (true);
create policy "Public can read songs" on public.songs for select using (true);
create policy "Public can read game rounds" on public.game_rounds for select using (true);
create policy "Public can read selections" on public.contestant_song_selections for select using (true);
create policy "Public can read badges" on public.badges for select using (true);
create policy "Public can read leaderboard" on public.leaderboard_snapshots for select using (true);
create policy "Public can read clips" on public.confessional_clips for select using (true);
create policy "Public can read AR anchors" on public.ar_venue_anchors for select using (true);

create policy "Users can read own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);
create policy "Users can read own predictions" on public.predictions for select using (auth.uid() = user_id);
create policy "Users can insert own predictions" on public.predictions for insert with check (auth.uid() = user_id);
create policy "Users can update own unlocked predictions" on public.predictions for update using (auth.uid() = user_id and locked = false);
create policy "Users can read own user badges" on public.user_badges for select using (auth.uid() = user_id);
