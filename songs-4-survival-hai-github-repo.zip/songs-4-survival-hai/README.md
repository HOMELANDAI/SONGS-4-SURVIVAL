# Songs 4 Survival by HAI

**Songs 4 Survival by HAI** is an interactive music survival game show and livestream experience where contestants cut massive song lists down through increasingly difficult rounds while viewers predict outcomes, earn XP, unlock badges, and compete on leaderboards.

Secondary concept title: **Desert Island Draft: Keeps & Cuts - Anthem Edition**

The experience blends music curation, game-show drama, livestream interaction, viewer prediction mechanics, HAI-branded XP and badges, tropical live-event production, Supabase-backed profiles, and optional AR venue integration.

## Core Concept

Contestants begin with a large pool of music and cut down to their most essential songs.

```text
Master Song List -> Top 100 -> Top 50 -> Top 25 -> Final 15 -> Secret 10 Ranked Reveal
```

The drama comes from emotional pressure, public versus private favorites, and the discovery that one contestant's #1 song may be another contestant's early cut.

## Repository Structure

```text
songs-4-survival-hai/
├── README.md
├── PROJECT_OVERVIEW.md
├── GAME_RULES.md
├── ROADMAP.md
├── LICENSE
├── .env.example
├── docs/
│   ├── prompts/
│   ├── production/
│   └── branding/
├── supabase/
│   ├── migrations/
│   └── seed/
├── src/
│   ├── data/
│   ├── lib/
│   └── components/
└── public/assets/
```

## Recommended Stack

HomelandAI uses Supabase for backend development. This repo is structured for:

- Frontend: Next.js, React, Vite, or similar
- Backend: Supabase
- Database: PostgreSQL via Supabase
- Auth: Supabase Auth
- Realtime: Supabase Realtime for leaderboards and live prediction updates
- Storage: Supabase Storage for contestant images, badges, clips, and media assets
- Deployment: Vercel, Netlify, or Cloudflare Pages

## Main Website Pages

1. Homepage
2. Game Mechanics
3. Viewer Prediction Dashboard
4. Badge Gallery
5. Live Leaderboard
6. Contestant Profiles
7. Livestream Watch Page
8. AR / AUKI Domains Integration
9. Venue Experience
10. Mobile Companion Screens

## Brand Direction

Visual identity: deep navy, electric cyan, neon teal, HAI gold, tropical orange, flame amber, sunset magenta, dark glassmorphism panels, palm silhouettes, tiki torch glow, digital song boards, Secret 10 vault motif, suitcase and song-fortune slip motif.

Tagline: **Every cut tells a story.**
