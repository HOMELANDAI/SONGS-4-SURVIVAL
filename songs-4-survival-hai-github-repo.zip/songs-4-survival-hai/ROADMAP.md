# Roadmap

## Phase 1 - Concept Prototype
- Finalize title and naming
- Build visual identity
- Build Figma prototype
- Build Gemini website prototype
- Create Supabase schema
- Define sample seed data
- Draft production run-of-show
- Draft livestream overlay specs

## Phase 2 - Web MVP
- Homepage
- Game rules page
- Prediction dashboard
- Badge gallery
- Leaderboard page
- Contestant profiles
- Supabase Auth
- Supabase database connection
- Basic admin tools for songs and rounds

## Phase 3 - Livestream Integration
- Twitch/YouTube/Maestro watch page
- Live chat placeholder
- Prediction lock timer
- Live poll module
- Leaderboard updates
- Badge unlock toasts
- Confessional clip cards

## Phase 4 - Venue Pilot
- Covered tropical venue layout
- Three contestant tables
- Digital boards behind contestants
- Crowd-facing screen
- QR code prediction entry
- Live host flow
- Confessional capture
- Social clip workflow

## Phase 5 - AR / AUKI Domains Layer
- Map physical anchor points
- AR leaderboard anchors
- AR voting panels
- Floating song fortunes
- HAI badge collection view
- Virtual venue prototype
- Sponsorship-ready AR placements

## Phase 6 - Full Season System
- Multi-event leaderboard
- Monthly champion
- Seasonal Hall of Fame
- Expanded badges
- Sponsor modules
- Premium viewer access
- Creator/contestant applications
