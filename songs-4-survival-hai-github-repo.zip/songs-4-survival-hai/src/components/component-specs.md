# Component Specs

## Core Components

### NavBar
Props: logo, navItems, user, liveStatus

### HeroSection
Props: headline, subheadline, tagline, ctaPrimary, ctaSecondary, visualAsset

### SongCard
Props: id, title, artist, genre, decade, mood, status, selected, locked

### RoundCard
Props: phase, title, fromCount, toCount, timeLimit, contestantTask, viewerChallenge

### PredictionCard
Props: predictionType, selectedSongs, lockStatus, pointsAvailable

### SecretVault
Props: locked, revealState, rankingSlots, contestant

### BadgeCard
Props: name, rarity, description, unlocked, xpReward

### LeaderboardRow
Props: rank, username, xp, accuracy, badges, streak

### PollBar
Props: option, percentage, voteCount

### CountdownTimer
Props: deadline, label, expiredState

### XPBurstToast
Props: points, reason, badgeUnlocked

### ErrorBanner
Props: message, actionLabel
