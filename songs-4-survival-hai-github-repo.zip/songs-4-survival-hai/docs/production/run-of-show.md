# Production Run of Show

## Pre-Show
- Display countdown timer
- Show HAI branding
- Show current leaderboard
- Explain rules
- Open viewer predictions
- Introduce contestants
- Introduce round stakes

## Segment 1 - Contestant Board Reveal
- Host introduces current cutdown round
- Each contestant board is shown
- Color-coded statuses are explained
- Audience sees current song pool
- Viewer prediction window opens

## Segment 2 - Individual Review
For each contestant:
- review kept songs
- discuss major cuts
- discuss genre patterns
- discuss artist loyalty
- discuss mood consistency
- play confessional clip
- show analytics overlay

## Segment 3 - Group Comparison
Host compares:
- universal keeps
- universal cuts
- crossover songs
- unique survivors
- shocking disagreements
- era differences
- mood differences
- private versus public taste

## Segment 4 - Viewer Challenge Results
- close predictions
- calculate points
- show leaderboard update
- unlock badges
- highlight top predictors
- trigger XP animations

## Segment 5 - Secret Vault Reveal
- open Secret 10 vault
- reveal rankings #10 to #1
- compare each song against other contestants' cuts
- ask why each song is personal
- show audience poll results
- reveal #1 Prophet winners

## Segment 6 - Closing
- announce next round deadline
- show current leaderboard
- tease next cut
- promote social clips
- invite viewers to return
- display HAI social links
