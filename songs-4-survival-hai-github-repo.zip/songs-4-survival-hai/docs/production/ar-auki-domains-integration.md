# AR / AUKI Domains Integration

## Concept
The venue can use AUKI Domains-style spatial AR to turn the physical Songs 4 Survival location into a mixed-reality game space.

## Physical Venue AR Features

### Geo-Anchored Leaderboards
Floating leaderboard panels above or near the main stage.

### AR Voting Panels
Audience members scan a QR code or use phone view to vote on song survival, Secret 10 predictions, #1 song guesses, era predictions, and surprise factor calls.

### Contestant Profile Anchors
Each contestant table can reveal profile, current round, song count, genre breakdown, mood meter, and hidden Secret 10 lock status.

### Floating Song Fortunes
Animated paper slips with song titles float from virtual suitcases across the venue.

### XP Badge Bursts
Correct predictions trigger HAI-branded badge bursts or confetti in AR.

### AR Drink Specials
Beach bar specials or sponsor offers appear as AR cards.

### Virtual Venue Mode
Remote viewers can enter a WebAR-style or 3D venue mode to explore boards, badges, leaderboard, Secret Vault, sponsor objects, and recap moments.

## Livestream AR Features
- AR overlay on main stream
- animated song slips
- Secret 10 vault opening
- poll bars floating over video
- HAI holographic logo
- XP and badge animations
- audience prediction heat map
