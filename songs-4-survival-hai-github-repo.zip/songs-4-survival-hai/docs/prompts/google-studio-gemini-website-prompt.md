# Google Studio Gemini Website Build Prompt

Build a vivid, interactive, production-ready website for **Songs 4 Survival by HAI**, a tropical music survival game show where contestants cut massive song lists down through dramatic rounds while viewers predict outcomes, earn XP, unlock badges, and interact with livestream and AR-enhanced venue features.

The site should feel like a fusion of Twitch competition overlay, Maestro.tv premium event hub, tropical nightlife venue, interactive music game show, and HomelandAI/HAI-branded digital entertainment platform.

## Website Pages
1. Homepage
2. Game Mechanics
3. Viewer Prediction Dashboard
4. Badge Gallery
5. Live Leaderboard
6. Contestant Profiles
7. Livestream Watch Page
8. AR / AUKI Domains Integration
9. Venue Experience
10. Mobile Companion Screens

## Visual Direction
Use deep navy blue, electric cyan, neon teal, metallic gold, tropical orange, sunset magenta, warm tiki flame amber, black glass panels, glowing blue outlines, and subtle palm-frond silhouettes.

Design with cinematic tropical tech, glowing digital boards, beach bar competition, tiki torch night energy, neon AR overlays, glassmorphism, Figma-inspired modular dashboard, premium music game show, Twitch/Maestro livestream UI, and HAI-branded futuristic island interface.

## Homepage
Hero headline: **SONGS 4 SURVIVAL**
Subheadline: **Presented by HAI**
Supporting text: **A live music survival game where contestants cut massive song lists down to their true musical DNA - while viewers predict, vote, earn XP, and unlock HAI badges.**

CTA buttons:
- Enter the Next Cutdown
- Watch the Live Round
- Play Along as a Viewer

Add ticker: **100 -> 50 -> 25 -> 15 -> Secret 10 Reveal**

## Game Mechanics
Build visual flow: **Master List -> Top 100 -> Top 50 -> Top 25 -> Final 15 -> Secret 10 Ranked Reveal**

Each phase card includes round name, time limit, contestant task, viewer challenge, and points available.

## Prediction Dashboard
Build modules:
1. Which Songs Survive This Round?
2. Guess the Secret 10
3. Full Ranking Challenge
4. Top 3 Oracle Challenge
5. #1 Prophet Challenge
6. Era Prediction
7. Surprise Factor
8. Crossover Challenge

Implement drag-and-drop for ranking and song selection if possible.

## Scoring
- +1 correct survival prediction
- +2 correct Secret 10 song
- +5 correct Top 3 exact placement
- +10 correct #1 song
- +5 correct era prediction
- +5 correct surprise factor
- +7 correct crossover
- +25 perfect Secret 10 set
- +50 exact full 1-10 ranking

## Badges
Include Ranking Master, Top 3 Oracle, #1 Prophet, Era Whisperer, Crossover King, Crossover Queen, Surprise Factor Sleuth, Survival Streak, Cutdown Champ, Secret 10 Oracle, Deep Cut Detective, Guilty Pleasure Prophet.

## Supabase Requirements
Structure code so it can later connect to Supabase. Use placeholder data models for profiles, contestants, songs, game_rounds, contestant_song_selections, predictions, badges, user_badges, leaderboard_snapshots, confessional_clips, and ar_venue_anchors.

## Interactivity
Implement mock login/profile state, prediction lock-in, point calculation demo, leaderboard update demo, badge unlock animation, song card drag-and-drop, Secret 10 vault reveal animation, countdown timer, responsive mobile layout, live poll demo, and share buttons.

## Troubleshooting / Debugging
Include component separation, mock JSON seed data, comments explaining scoring, validation for drag-and-drop state, duplicate song prevention, no edits after prediction lock, user-friendly errors, fallback image states, hover/focus states, desktop/tablet/mobile breakpoints, contrast accessibility on neon backgrounds, prevention of NaN leaderboard scores, tab state preservation, and placeholder API functions for Supabase.
