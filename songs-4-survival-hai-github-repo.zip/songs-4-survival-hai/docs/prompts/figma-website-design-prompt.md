# Figma Website Design Prompt

Design a high-fidelity Figma website prototype for **Songs 4 Survival by HAI**, a tropical interactive music survival contest where contestants cut down huge song lists while viewers predict results, earn XP, unlock badges, and engage through livestream and AR-enhanced venue experiences.

The design should capture the energy of a premium tropical game show, livestream prediction dashboard, Maestro.tv interactive hub, Twitch overlay, and HAI-branded music-tech entertainment universe.

## Figma Pages
1. Design System
2. Homepage
3. Game Mechanics
4. Prediction Dashboard
5. Badge Gallery
6. Leaderboard
7. Contestant Profiles
8. Livestream Watch Page
9. AR Venue Integration
10. Venue Experience
11. Mobile Screens
12. Component Library

## Design Language
Use dark glassmorphism panels, neon cyan borders, metallic gold typography, glowing orange tiki/fire accents, tropical palm silhouettes, subtle waveform textures, digital grid overlays, vinyl record icons, suitcase and fortune-slip motifs, Secret 10 vault graphics, HAI badge elements, and AR hologram overlays.

## Color Palette
- Midnight Navy: #061426
- Deep Ocean Blue: #082B46
- Electric Cyan: #00E5FF
- Neon Teal: #11FFD2
- HAI Gold: #FFC533
- Tropical Orange: #FF7A1A
- Flame Amber: #FFB347
- Sunset Magenta: #D946EF
- Cut Red: #FF3B30
- Keep Green: #35E96B
- Unique Yellow: #FFD84D

## Homepage
Left side: large stacked logo SONGS 4 SURVIVAL, subline Presented by HAI, tagline Every cut tells a story, CTA buttons Play the Next Cut, Watch Live, View Rules.

Right side: glowing digital suitcase, song slips flying out, slips reading Secret 10, #1 Prophet, Deep Cut, Final 15, glowing HAI seal, and beach bar silhouette.

## Prediction Dashboard
Top bar: HAI logo, event name, live indicator, next cut countdown, user XP, profile avatar.

Left column: Survival Prediction with song cards and lock button.

Center column: Secret 10 Vault with drag-and-drop ranked slots #10 to #1, locked vault state, and reveal pending state.

Right column: points, badges, streak, leaderboard rank, and next badge progress.

Bottom tabs: Survivor Picks, Secret 10, Top 3 Oracle, #1 Prophet, Era Prediction, Crossover Call, Surprise Factor.

## Badge Gallery
Design badge cards for Ranking Master, Top 3 Oracle, #1 Prophet, Era Whisperer, Crossover King, Crossover Queen, Surprise Factor Sleuth, Survival Streak, Cutdown Champ, Secret 10 Oracle, Deep Cut Detective, and Guilty Pleasure Prophet.

## Livestream Page
Main video player on left. Right column has live chat, live poll, prediction entry widget, leaderboard mini-widget, and badge unlock feed.

Video overlay includes next cut timer, audience poll, contestant columns, confessional pop-up, XP burst, Secret Vault animation, analytics slide-in, and HAI watermark.

## AR Venue Integration
Page title: **Live Venue AR powered by HAI + AUKI Domains**

Visual: tropical pavilion, AR leaderboards floating over contestant tables, audience phones scanning, digital song fortunes floating, Secret 10 vault hologram, HAI logo projected in the sky.

Feature cards: Geo-Anchored Leaderboards, AR Voting Panels, Floating Song Fortunes, XP Badge Bursts, Secret Vault Reveal, Virtual Venue Mode, AR Drink Specials, HAI Badge Case.

## Venue Experience
Create cards for Golden Hour Reveal, Midnight Cutdown Frenzy, and Anthem Finale Under the Tiki Stars.

Use tiki torches, fire bowls, electronic boards, beach bar, palm-thatch pavilion, sunset and night skies, HAI banners, small crowd, and contestant tables.

## Prototype Interactions
Homepage -> Play the Next Cut -> Prediction Dashboard -> Select songs -> Lock prediction -> Success toast -> Earn XP -> Badge unlock -> Leaderboard rank moves up -> Secret Vault opens -> Secret 10 ranking reveal -> Share badge to social.

Use smart animate for vault opening, badge unlock, song card selected, leaderboard rank movement, XP burst, poll bar growth, and tab transitions.

## QA Notes
Ensure readable contrast, legible mobile song cards, obvious locked/unlocked states, consistent status colors, empty/error/locked states, 1440 desktop, 1024 tablet, and 390 mobile frames, and visible but not overwhelming HAI branding.
