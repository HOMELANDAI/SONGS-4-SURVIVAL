# Visual Identity

## Brand Name
Songs 4 Survival by HAI

## Tagline
Every cut tells a story.

## Secondary Title
Desert Island Draft: Keeps & Cuts - Anthem Edition

## Visual Themes
- tropical game show
- neon music survival
- tiki torch venue
- digital prediction dashboard
- premium livestream overlay
- HAI-branded AR environment
- beach bar adventure
- Secret 10 vault reveal
- suitcase with song fortune slips

## Color Palette
| Name | Hex |
|---|---|
| Midnight Navy | #061426 |
| Deep Ocean Blue | #082B46 |
| Electric Cyan | #00E5FF |
| Neon Teal | #11FFD2 |
| HAI Gold | #FFC533 |
| Tropical Orange | #FF7A1A |
| Flame Amber | #FFB347 |
| Sunset Magenta | #D946EF |
| Cut Red | #FF3B30 |
| Keep Green | #35E96B |
| Unique Yellow | #FFD84D |

## UI Motifs
- glassmorphism panels
- glowing song cards
- digital boards
- neon outlines
- circular vinyl icons
- ranking slots
- lockbox / vault visuals
- gold HAI badge
- palm silhouettes
- tiki flame edges
- XP confetti
- badge unlock toasts

## Status Colors
- Green = kept
- Red = cut
- Yellow = unique survivor
- Gold = Secret Highlight
- Blue lock = hidden
- Purple = active audience prediction
- Cyan = XP / system feedback
