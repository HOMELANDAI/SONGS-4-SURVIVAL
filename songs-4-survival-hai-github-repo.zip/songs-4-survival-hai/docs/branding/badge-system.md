# Badge System

Badges are HAI-branded collectibles awarded to viewers for prediction achievements.

## Badge Design Style
- metallic shield shapes
- cyan glow
- gold trim
- vinyl records
- music notes
- lockbox icons
- crowns
- radio dials
- magnifying glass
- tropical neon accents
- HAI emblem

## Badge List

### Ranking Master
Earned for correctly predicting a full Secret 10 ranking.

### Top 3 Oracle
Earned for correctly predicting a contestant's Top 3.

### #1 Prophet
Earned for correctly predicting a contestant's #1 song.

### Era Whisperer
Earned for correctly predicting the decade of a #1 song.

### Crossover King / Queen
Earned for identifying songs that appear in multiple Secret 10 lists.

### Surprise Factor Sleuth
Earned for correctly calling whether a #1 song is an obvious classic, deep cut, or guilty pleasure.

### Survival Streak
Earned for consecutive correct predictions.

### Cutdown Champ
Earned for winning a live round leaderboard.

### Secret 10 Oracle
Earned for identifying all Secret 10 songs, even if order is imperfect.

### Deep Cut Detective
Earned for correctly predicting a deep cut that survives.

### Guilty Pleasure Prophet
Earned for correctly predicting a guilty pleasure as a high-ranking favorite.

## Rarity Tiers
- Common
- Rare
- Epic
- Legendary
- Mythic HAI
