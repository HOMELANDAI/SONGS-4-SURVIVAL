# Game Rules

## Game Title
**Songs 4 Survival by HAI**

## Secondary Format Name
**Desert Island Draft: Keeps & Cuts - Anthem Edition**

## Setup
Each contestant receives the same master song source: 8 to 10 double-sided laminated genre sheets, roughly 75 songs per side, approximately 1,200 to 1,500 total songs.

## Phase 0 - Top 100 Selection

**Time Limit:** 48 hours

Contestants choose 100 favorite songs from the master list. This reveals broad music identity: genre attraction, favorite eras, artist loyalty, obvious classics, guilty pleasures, deep cuts, and emotional anchors.

## Phase 1 - 100 to 50

**Name:** The First Cut  
**Time Limit:** 48 hours

Contestants cut 100 songs down to 50.

Review discussion:
- which songs survived
- which songs were surprisingly cut
- repeat artists
- genre concentration
- mood patterns
- decade clusters
- overlap between contestants

Viewer challenge: predict which songs survive to the 50.

## Phase 2 - 50 to 25

**Name:** The Essence Cut  
**Time Limit:** 24 hours

Contestants reduce 50 songs to 25. Each contestant privately chooses **10 Secret Highlights** from the 25. The Secret 10 are not publicly discussed yet.

Viewer challenge: predict which songs survived and which are in the Secret 10.

## Phase 3 - 25 to 15

**Name:** The Final Brutal Cut  
**Time Limit:** 24 hours

Contestants cut 25 songs down to 15 and rank their Secret 10 from #10 to #1.

Viewer challenge:
- final 15 survivors
- Secret 10 songs
- full Secret 10 ranking
- Top 3
- #1 song
- era of #1
- surprise factor
- crossover songs between contestants

## Phase 4 - Live Finale

**Name:** The Secret Vault Reveal

Each contestant reveals their Secret 10 from #10 to #1. The host discusses personal meaning, songs other contestants cut, crossover moments, obvious classics, deep cuts, guilty pleasures, and shocking rankings.

## Color Coding

- Green = kept
- Red = cut
- Yellow = unique survivor
- Gold star = Secret Highlight
- Blue lock = hidden or unrevealed
- Purple glow = audience prediction active
- Cyan flash = XP or badge unlock

## Suggested Scoring

- +1 correct survival prediction
- +2 correct Secret 10 song
- +5 correct Top 3 exact placement
- +10 correct #1 song
- +5 correct era prediction
- +5 correct surprise factor
- +7 correct crossover song
- +25 bonus for perfect Secret 10 song set
- +50 jackpot for exact full Secret 10 order
