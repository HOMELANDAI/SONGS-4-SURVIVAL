# OBS Scene Collection Spec

## Scene Collection Name

Songs 4 Survival Live

---

## Scene 1 — STARTING SOON

Sources:
- Background animation
- HAI logo
- countdown browser source
- social icons
- music bed
- next round title

Overlay route:
```text
/overlay/countdown
```

---

## Scene 2 — HOST OPEN

Sources:
- Host camera
- lower-third browser source
- HAI watermark
- event title
- chat/poll mini overlay

---

## Scene 3 — MAIN GAME VIEW

Sources:
- wide venue camera
- contestant table cameras as picture-in-picture
- main overlay browser source
- countdown
- HAI watermark

Overlay route:
```text
/overlay/main
```

---

## Scene 4 — CONTESTANT BOARD 1

Sources:
- contestant 1 camera
- board capture
- contestant lower-third
- song list overlay
- analytics mini panel

---

## Scene 5 — CONTESTANT BOARD 2

Same as contestant board 1.

---

## Scene 6 — CONTESTANT BOARD 3

Same as contestant board 1.

---

## Scene 7 — THREE BOARD COMPARISON

Sources:
- three digital boards
- overlap map
- universal keeps/cuts
- host camera picture-in-picture

Overlay route:
```text
/overlay/analytics
```

---

## Scene 8 — PREDICTION LOCK-IN

Sources:
- prediction dashboard overlay
- countdown timer
- active challenge cards
- chat reminder

Overlay route:
```text
/overlay/prediction-window
```

---

## Scene 9 — AUDIENCE POLL

Sources:
- poll browser source
- crowd camera
- host camera
- poll bar animation

Overlay route:
```text
/overlay/poll
```

---

## Scene 10 — ANALYTICS BREAKDOWN

Sources:
- genre pie chart
- decade histogram
- repeat artist bar
- mood meter

Overlay route:
```text
/overlay/analytics
```

---

## Scene 11 — CONFESSIONAL CLIP

Sources:
- media source clip
- lower third
- emotion tag
- song cut label

---

## Scene 12 — SECRET VAULT REVEAL

Sources:
- vault animation browser source
- contestant camera
- host camera
- ranking cards

Overlay route:
```text
/overlay/secret-vault
```

---

## Scene 13 — LEADERBOARD UPDATE

Sources:
- leaderboard overlay
- XP animation
- top 5 viewers
- rank movement

Overlay route:
```text
/overlay/leaderboard
```

---

## Scene 14 — BADGE UNLOCK MOMENT

Sources:
- badge unlock overlay
- user name
- points
- badge icon
- sound effect

Overlay route:
```text
/overlay/badge-unlock
```

---

## Scene 15 — AR VENUE MOMENT

Sources:
- wide venue camera
- AR-style overlay
- floating song fortunes
- HAI + AUKI branding

---

## Scene 16 — BRB / INTERMISSION

Sources:
- intermission graphic
- social links
- music bed
- countdown

---

## Scene 17 — ENDING / NEXT ROUND TEASE

Sources:
- host camera
- next round CTA
- social icons
- website link
- HAI logo
