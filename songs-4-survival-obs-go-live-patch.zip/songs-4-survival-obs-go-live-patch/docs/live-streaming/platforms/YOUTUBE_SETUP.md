# YouTube Live Setup

## Purpose

Use YouTube for:

- private/unlisted testing
- public livestreams
- replay archive
- searchable long-form episodes
- Shorts recap funnel

---

## Recommended YouTube Use

Start with unlisted test streams before going public.

YouTube is especially useful for:

- production rehearsals
- archiving full episodes
- publishing edited recaps
- building Shorts from confessionals and reveal moments

---

## OBS YouTube Setup

1. Open YouTube Studio.
2. Create a live event.
3. Copy stream key.
4. Open OBS.
5. Go to Settings > Stream.
6. Select YouTube - RTMPS.
7. Paste stream key.
8. Set bitrate:
   - 6000 Kbps for stable 1080p
   - 9000 Kbps for stronger quality if internet supports it
9. Start stream in OBS.
10. Go live in YouTube Studio.

---

## Best YouTube Content

- full episode archive
- Secret 10 reveal clips
- Top 10 countdown videos
- contestant confessionals
- highlight shorts
- audience prediction results
- badge winner recaps

---

## YouTube Shorts Funnel

Create Shorts from:

- "I can't believe I cut this song"
- shocking #1 reveal
- host reaction
- crowd reaction
- leaderboard upset
- guilty pleasure reveal
- deep cut defense

Each Short should push viewers to:

- next live stream
- prediction dashboard
- HAI website
- Discord/community
