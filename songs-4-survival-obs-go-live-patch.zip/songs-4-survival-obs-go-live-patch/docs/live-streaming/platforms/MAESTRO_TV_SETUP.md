# Maestro.tv Setup

## Purpose

Use Maestro.tv for premium interactive Songs 4 Survival experiences.

Maestro is best suited for:

- sponsor-backed events
- VIP viewer experiences
- controlled premium streams
- interactive modules
- branded engagement
- ticketed or private events

---

## Maestro Positioning

Position Songs 4 Survival on Maestro as:

- a premium HAI music survival event
- an interactive prediction experience
- a live digital venue
- a sponsor-ready entertainment property

---

## OBS to Maestro

Maestro setup may vary by event configuration.

General path:

1. Create Maestro event.
2. Configure live stream source.
3. Retrieve RTMP ingest URL and stream key.
4. Open OBS.
5. Settings > Stream.
6. Select Custom.
7. Paste Maestro RTMP server URL.
8. Paste stream key.
9. Test stream privately.
10. Verify embedded overlays and interactive modules.

---

## Maestro Interactive Modules

Use Maestro for:

- prediction panel
- sponsor panel
- live poll
- leaderboard
- VIP chat
- merch unlock
- badge claim
- exclusive content
- post-show replay

---

## Maestro Premium Features

Recommended premium layers:

- VIP prediction room
- bonus badges
- exclusive confessional clips
- early access to next round
- sponsor rewards
- HAI profile achievements
- virtual venue experience

---

## Maestro Risk Notes

Maestro may not deliver the same organic discovery as Twitch or YouTube.

Drive traffic from:

- Instagram
- TikTok
- YouTube Shorts
- Twitch previews
- Discord
- HAI website
- email/text campaigns
- venue QR codes
