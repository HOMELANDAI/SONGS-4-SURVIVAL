# Twitch Setup

## Purpose

Use Twitch for discovery, chat energy, live reactions, and community testing.

---

## Twitch Positioning

Position Songs 4 Survival as:

- a music identity game show
- a live prediction contest
- a ranking/debate format
- a viewer participation event

Avoid positioning it as a full music playback stream unless rights are cleared.

---

## OBS Twitch Setup

1. Open OBS.
2. Go to Settings.
3. Go to Stream.
4. Select Service: Twitch.
5. Connect account or paste stream key.
6. Set output bitrate around 6000 Kbps for 1080p.
7. Set keyframe interval to 2 seconds.
8. Run a test stream if possible.

---

## Recommended Twitch Scenes

- Starting Soon
- Main Game View
- Prediction Lock-In
- Audience Poll
- Secret Vault Reveal
- Leaderboard Update
- Badge Unlock Moment
- Ending Screen

---

## Twitch Engagement

Use:

- Twitch chat
- polls
- pinned chat instructions
- !rules command
- !predict command
- !leaderboard command
- clip prompts
- mod reminders

---

## Twitch Chat Commands

Suggested commands:

```text
!rules
!play
!predict
!leaderboard
!badges
!contestants
!nextcut
!hai
```

These can link to the Songs 4 Survival website.

---

## Twitch Risk Notes

Copyright is the major risk.

Use:
- licensed music beds
- original HAI stingers
- commentary
- song title boards
- cleared clips only

Avoid:
- full copyrighted songs
- long recognizable music playback
- unlicensed DJ-style sets during the broadcast
