# Technical Runbook

## Purpose

This runbook gives the production team a repeatable workflow for running Songs 4 Survival live using OBS, Supabase, and livestream platforms.

---

# 1. Roles

## Producer
Owns show timing and segment flow.

## Technical Director
Runs OBS scenes and monitors stream output.

## Host
Leads the show, explains rules, interviews contestants, cues reveals.

## Game Admin
Controls prediction windows, round locks, reveals, scoring, and leaderboard updates.

## Chat / Community Mod
Watches Twitch/YouTube/Maestro chat and flags audience moments.

## Clip Producer
Marks confessionals, reactions, and reveal moments for social clips.

---

# 2. Pre-Show Technical Setup

## OBS

- Load scene collection
- Confirm all cameras
- Confirm all microphones
- Confirm browser overlays
- Confirm stream key
- Confirm recording path
- Confirm transition stingers
- Confirm audio meters
- Confirm stream bitrate

## Supabase

- Confirm event status is live-ready
- Confirm contestants exist
- Confirm songs exist
- Confirm current round is correct
- Confirm prediction window is correct
- Confirm leaderboard is empty or reset
- Confirm badges exist
- Confirm realtime connection

## Website

- Test viewer dashboard
- Test prediction submission
- Test prediction lock
- Test leaderboard update
- Test badge unlock
- Test mobile layout
- Test social share buttons

---

# 3. Live Show Flow

## Segment A — Starting Soon

OBS Scene:
STARTING SOON

Actions:
- show countdown
- show HAI branding
- show social links
- show tonight's round
- open chat

## Segment B — Host Open

OBS Scene:
HOST OPEN

Actions:
- host welcomes viewers
- explain rules
- introduce contestants
- explain prediction opportunities

## Segment C — Open Predictions

OBS Scene:
PREDICTION LOCK-IN

Game Admin:
- opens prediction window in Supabase
- confirms dashboard accepts entries
- confirms OBS overlay shows active timer

## Segment D — Contestant Reviews

OBS Scenes:
- CONTESTANT BOARD 1
- CONTESTANT BOARD 2
- CONTESTANT BOARD 3

Actions:
- review keeps
- review cuts
- show analytics
- show confessional clip
- ask emotional why

## Segment E — Group Comparison

OBS Scene:
THREE BOARD COMPARISON

Actions:
- compare overlaps
- identify unique survivors
- identify universal cuts
- discuss crossover songs

## Segment F — Lock Predictions

OBS Scene:
PREDICTION LOCK-IN

Game Admin:
- locks predictions
- confirms no new edits
- triggers lock overlay

## Segment G — Reveal Results

OBS Scenes:
- SECRET VAULT REVEAL
- LEADERBOARD UPDATE
- BADGE UNLOCK MOMENT

Actions:
- reveal round results
- calculate points
- update leaderboard
- trigger badges
- shout out top viewers

## Segment H — Close

OBS Scene:
ENDING / NEXT ROUND TEASE

Actions:
- show next deadline
- promote socials
- promote next stream
- push viewers to website
- end stream
- stop recording after stream ends

---

# 4. Emergency Fallbacks

## If Supabase Realtime Drops

- keep stream running
- switch to static OBS graphics
- use manual leaderboard screenshot
- restart browser source
- reload overlay URL
- continue show verbally

## If Prediction Dashboard Fails

- announce manual fallback
- use Twitch/YouTube/Maestro poll
- continue show
- record issue for post-show fix

## If Audio Fails

- switch to backup microphone
- reduce background music
- confirm audio meter in OBS
- ask chat if audio is restored

## If Internet Drops

- use backup hotspot if available
- keep local recording running
- resume stream if connection returns
- upload full recording later if needed

## If Copyright Warning Appears

- stop any music playback immediately
- switch to commentary only
- use licensed HAI music bed
- continue with song names, rankings, and discussion

---

# 5. Post-Show

- stop stream
- stop recording
- backup recording
- export highlights
- verify final leaderboard
- publish badge results
- post recap clips
- save production notes
- schedule next round
