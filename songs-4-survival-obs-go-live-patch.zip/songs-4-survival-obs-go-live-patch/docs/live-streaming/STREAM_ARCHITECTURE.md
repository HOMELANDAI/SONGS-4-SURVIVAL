# Stream Architecture

## System Overview

Songs 4 Survival uses a three-layer architecture:

```text
Live Venue / Studio
        ↓
OBS Studio Broadcast Control
        ↓
Twitch / YouTube / Maestro.tv

Website / Viewer App
        ↓
Supabase Backend
        ↓
OBS Browser Overlays + Viewer Dashboards
```

---

## 1. Venue / Studio Layer

### Inputs

- Host camera
- Contestant cameras
- Wide venue camera
- Crowd reaction camera
- Digital board capture
- Host mic
- Contestant mics
- Room/crowd mic
- Confessional clips
- HAI transition graphics

### Venue Elements

- three contestant tables
- electronic boards behind contestants
- small live crowd
- covered tropical pavilion
- tiki lights / flame effects
- beach bar setting
- HAI signage
- optional AR markers / QR codes

---

## 2. OBS Layer

OBS acts as:

- camera switcher
- audio mixer
- overlay compositor
- stream encoder
- recording system
- scene control surface

OBS receives browser overlays from the Songs 4 Survival web app.

Example browser overlays:

```text
/overlay/main-game
/overlay/prediction-window
/overlay/countdown
/overlay/poll-results
/overlay/leaderboard
/overlay/badge-unlock
/overlay/secret-vault
/overlay/analytics
```

---

## 3. Supabase Layer

Supabase manages:

- event state
- current round
- active prediction window
- contestant song lists
- viewer predictions
- scoring
- badges
- leaderboard
- clip metadata
- overlay cue state

### Supabase Realtime

Use Supabase Realtime for:

- leaderboard updates
- prediction lock state
- poll result updates
- badge unlock feed
- overlay cue updates
- current round state

---

## 4. Viewer Website Layer

Viewer-facing routes:

```text
/
/watch
/play
/predict
/leaderboard
/badges
/contestants
/rules
/venue-ar
```

Admin routes:

```text
/admin/live-control
/admin/events
/admin/rounds
/admin/songs
/admin/scoring
```

Overlay routes:

```text
/overlay/main
/overlay/countdown
/overlay/poll
/overlay/leaderboard
/overlay/badge-unlock
/overlay/secret-vault
/overlay/analytics
/overlay/lower-third
```

---

## 5. Platform Output Layer

### Twitch

Best for:
- discovery
- chat energy
- community reactions
- clips
- audience testing

### YouTube

Best for:
- searchable archive
- long-form replay
- public discovery
- Shorts recap funnel
- private/unlisted technical tests

### Maestro.tv

Best for:
- premium interactive experiences
- sponsor-backed shows
- VIP access
- advanced event funnels
- controlled audience viewing

---

## 6. Recommended Production Flow

### Pilot 1
YouTube unlisted test.

Goal:
- verify OBS scenes
- verify overlay readability
- test Supabase realtime
- test audio sync

### Pilot 2
Twitch soft launch.

Goal:
- test audience response
- test chat/prediction engagement
- test live clipping

### Pilot 3
Maestro premium run.

Goal:
- test higher production value
- test sponsor-ready layout
- test VIP/premium interactivity

---

## 7. Data Flow Example

Viewer predicts a Secret 10 song:

```text
Viewer Dashboard
    ↓
Supabase predictions table
    ↓
Prediction locks when round timer expires
    ↓
Admin reveals actual Secret 10
    ↓
Scoring function calculates points
    ↓
Leaderboard snapshot updates
    ↓
OBS leaderboard overlay updates in realtime
    ↓
Badge unlock overlay appears
```

---

## 8. Overlay Cue Flow

Admin triggers "Secret Vault Reveal":

```text
/admin/live-control
    ↓
Supabase live_overlay_cues table
    ↓
Realtime channel broadcasts cue
    ↓
/overlay/secret-vault animates open
    ↓
OBS displays reveal scene
```
