# Pre-Show Checklist

## 24 Hours Before

- Confirm contestants' submitted lists
- Confirm current round data in Supabase
- Confirm prediction options are loaded
- Confirm Secret 10 data is hidden
- Confirm leaderboard reset/state
- Confirm badges are active
- Confirm show graphics
- Confirm OBS scene collection
- Confirm platform stream keys
- Confirm host script
- Confirm confessional clips
- Confirm sponsor/HAI assets
- Confirm social posts

---

## 3 Hours Before

- Test internet speed
- Test all cameras
- Test all mics
- Test OBS output
- Test browser overlays
- Test Supabase realtime
- Test prediction lock
- Test leaderboard update
- Test badge unlock animation
- Test stream to private destination
- Test recording

---

## 30 Minutes Before

- Start OBS
- Load correct scene collection
- Open all overlay browser sources
- Check audio meters
- Check video framing
- Check lighting
- Check chat/mod tools
- Check admin live-control panel
- Set event status to ready
- Put stream on Starting Soon scene

---

## 5 Minutes Before

- Confirm host is ready
- Confirm contestants are seated
- Confirm Game Admin is ready
- Confirm Technical Director is ready
- Confirm stream health
- Confirm recording
- Confirm prediction dashboard link
- Confirm social links
