# Live Show Checklist

## Start

- Start stream
- Start recording
- Show Starting Soon
- Verify platform health
- Confirm chat can hear audio

## Host Open

- Switch to Host Open
- Welcome viewers
- Introduce HAI
- Explain Songs 4 Survival
- Explain tonight's cut
- Explain viewer predictions

## Prediction Window

- Open predictions in Supabase
- Show prediction overlay
- Confirm viewer submissions
- Show countdown

## Contestant Segments

For each contestant:

- show board
- review keeps
- review cuts
- show analytics
- play confessional
- prompt host discussion
- remind viewers to predict

## Lock Predictions

- announce final warning
- lock predictions
- verify locked state
- show lock animation

## Reveal

- reveal results
- trigger scoring
- update leaderboard
- trigger badge unlocks
- shout out winners

## Close

- tease next round
- show social links
- direct viewers to website
- thank contestants and audience
- end stream
- stop recording
