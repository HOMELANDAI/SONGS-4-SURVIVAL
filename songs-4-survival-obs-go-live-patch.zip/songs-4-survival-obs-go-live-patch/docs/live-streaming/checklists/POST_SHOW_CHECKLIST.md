# Post-Show Checklist

## Immediately After

- Stop stream
- Stop OBS recording
- Backup recording
- Export chat if needed
- Save leaderboard snapshot
- Confirm badge awards
- Mark round complete in Supabase
- Save show notes

## Content

Create clips:

- best cut reaction
- best confessional
- biggest audience surprise
- #1 reveal
- leaderboard upset
- funny chat moment
- deep cut defense
- guilty pleasure reveal

## Publish

- YouTube full replay
- YouTube Shorts
- TikTok clips
- Instagram Reels
- X/Twitter highlights
- Discord recap
- HAI website recap

## Technical Review

Document:

- overlay issues
- audio issues
- stream drops
- dashboard bugs
- scoring errors
- confusing UX
- audience feedback
- improvements for next stream
