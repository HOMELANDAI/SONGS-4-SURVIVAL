# OBS Go-Live Guide

## Project

**Songs 4 Survival by HAI**

## Goal

Use **OBS Studio** as the broadcast command center for streaming Songs 4 Survival live to:

- Twitch
- YouTube Live
- Maestro.tv

while using **Supabase** as the backend for live predictions, scoring, badges, contestant states, and leaderboards.

---

# 1. Recommended Production Model

## OBS as the Broadcast Hub

OBS should manage:

- camera feeds
- host feed
- contestant table cameras
- digital board captures
- browser overlays
- prediction dashboard overlays
- leaderboard overlays
- confessional clips
- sponsor/HAI branding
- scene switching
- audio mixing
- stream output

## Supabase as the Live Game Backend

Supabase should manage:

- event records
- contestant profiles
- song lists
- current round state
- prediction entries
- locked prediction windows
- point scoring
- badge unlocks
- leaderboard updates
- confessional clip metadata
- AR venue anchor metadata

## Website as Interactive Layer

The Songs 4 Survival web app should provide:

- public watch page
- viewer prediction dashboard
- leaderboard page
- badge gallery
- host/admin control panel
- OBS-safe browser overlay routes

Example OBS browser source routes:

```text
/overlay/main
/overlay/countdown
/overlay/poll
/overlay/leaderboard
/overlay/badges
/overlay/secret-vault
/overlay/analytics
/overlay/confessional
/overlay/lower-thirds
```

---

# 2. OBS Scene Collection

Create one OBS scene collection named:

```text
Songs 4 Survival Live
```

Recommended scenes:

1. **STARTING SOON**
2. **HOST OPEN**
3. **MAIN GAME VIEW**
4. **CONTESTANT BOARD 1**
5. **CONTESTANT BOARD 2**
6. **CONTESTANT BOARD 3**
7. **THREE BOARD COMPARISON**
8. **PREDICTION LOCK-IN**
9. **AUDIENCE POLL**
10. **ANALYTICS BREAKDOWN**
11. **CONFESSIONAL CLIP**
12. **SECRET VAULT REVEAL**
13. **LEADERBOARD UPDATE**
14. **BADGE UNLOCK MOMENT**
15. **AR VENUE MOMENT**
16. **BRB / INTERMISSION**
17. **ENDING / NEXT ROUND TEASE**

---

# 3. Recommended OBS Sources

## Cameras

- Host camera
- Wide venue camera
- Contestant table camera 1
- Contestant table camera 2
- Contestant table camera 3
- Crowd reaction camera
- Optional mobile/roaming camera

## Audio

- Host mic
- Contestant mic 1
- Contestant mic 2
- Contestant mic 3
- Crowd/room mic
- Music bed / stingers
- Confessional clip audio

## Browser Sources

Use browser sources for Supabase-powered overlays:

- countdown timer
- active round name
- audience poll
- viewer leaderboard
- XP badge unlock
- Secret 10 vault reveal
- analytics panel
- contestant lower thirds
- social handles
- HAI watermark
- sponsor slate

## Media Sources

- intro video
- transition stingers
- confessional clips
- sponsor bumpers
- finale recap
- animated HAI logo

---

# 4. OBS Canvas Settings

Recommended settings for main production:

## Video

- Base Canvas: 1920x1080
- Output Scaled Resolution: 1920x1080
- FPS: 30 or 60
- Color Format: NV12
- Color Space: Rec.709
- Color Range: Partial

## Streaming Output

For broad compatibility:

- Encoder: Hardware encoder if available
  - NVIDIA NVENC
  - Apple VT H264
  - Intel QuickSync
- Rate Control: CBR
- Bitrate:
  - Twitch: 6000 Kbps recommended
  - YouTube: 6000–9000 Kbps for 1080p
  - Maestro.tv: follow event-specific ingest recommendation
- Keyframe Interval: 2 seconds
- Preset: Quality
- Profile: High
- Audio Bitrate: 160–320 Kbps

---

# 5. Streaming to Multiple Platforms

## Option A — One Platform at a Time

Start with one platform for the pilot.

Recommended pilot order:

1. YouTube unlisted/private test
2. Twitch public test
3. Maestro premium test

## Option B — Multistream Through Restream or Similar

OBS streams to a restream service, and that service distributes to:

- Twitch
- YouTube
- Maestro.tv if supported by the platform's ingest policy

## Option C — OBS Multiple RTMP Plugin

Use the OBS Multiple RTMP plugin to send to multiple platforms directly.

Only use this if the production computer and internet upload bandwidth are strong enough.

---

# 6. Minimum Internet Requirements

For stable 1080p:

- Minimum upload: 15 Mbps
- Preferred upload: 25 Mbps+
- Wired Ethernet strongly recommended
- Avoid Wi-Fi for the main encoder machine
- Have a phone hotspot backup
- Test venue internet during the same time of day as the show

---

# 7. OBS Browser Overlay Requirements

Each overlay page should:

- have transparent background support
- use 1920x1080 safe area layouts
- avoid heavy animations during stream-critical moments
- reconnect gracefully if Supabase realtime drops
- show fallback data if disconnected
- avoid showing undefined/NaN values
- use readable contrast on dark backgrounds
- support query params for scene control

Example:

```text
/overlay/leaderboard?eventId=abc123&limit=5
/overlay/countdown?roundId=round_50_25
/overlay/badges?eventId=abc123
```

---

# 8. Host/Admin Control Panel

Build or plan an admin route:

```text
/admin/live-control
```

Admin controls should allow the production operator to:

- set current scene state
- open/close predictions
- lock predictions
- reveal round results
- trigger Secret Vault reveal
- trigger badge animation
- trigger leaderboard update
- launch confessional clip
- mark round as complete
- push next segment cue to overlays

This control panel should write to Supabase tables or realtime channels.

---

# 9. Go-Live Flow

1. Open OBS.
2. Confirm scene collection is loaded.
3. Confirm camera/audio sources.
4. Open Songs 4 Survival website overlays.
5. Confirm Supabase connection.
6. Start private test stream.
7. Check audio sync.
8. Check overlay readability.
9. Open viewer prediction window.
10. Start public stream.
11. Run show using Technical Runbook.
12. End stream with next-round CTA.
13. Export recording and clips.
14. Post recap and update leaderboard.

---

# 10. Critical Warning: Music Rights

Songs 4 Survival should avoid relying on full copyrighted song playback unless rights are cleared.

Safer livestream format:

- show song titles
- discuss songs
- use licensed music beds
- use cleared short clips only when available
- emphasize rankings, debates, cuts, and predictions
- use original HAI stingers and sound effects

The show works best as a music identity / prediction game show, not a full-song playback stream.
