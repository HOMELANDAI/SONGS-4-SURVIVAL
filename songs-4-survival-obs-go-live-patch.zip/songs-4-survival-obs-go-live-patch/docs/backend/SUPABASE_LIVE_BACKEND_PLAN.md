# Supabase Live Backend Plan

## Purpose

HomelandAI uses Supabase for backend development. This plan defines how Supabase should support Songs 4 Survival live events, OBS overlays, viewer predictions, scoring, badges, and leaderboards.

---

## Core Supabase Responsibilities

Supabase should manage:

- users and profiles
- event state
- contestant data
- song list data
- round state
- predictions
- scoring
- badge unlocks
- leaderboard snapshots
- overlay cues
- livestream platform metadata
- AR venue anchors

---

## Realtime Requirements

Use Supabase Realtime for:

- current round changes
- prediction window open/closed state
- countdown lock state
- poll results
- scoring updates
- badge unlock feed
- leaderboard updates
- overlay cues
- Secret Vault reveal triggers

---

## Recommended Tables Added in This Patch

### livestreams

Stores platform-specific live stream records.

Fields:
- id
- event_id
- platform
- stream_url
- embed_url
- status
- starts_at
- ended_at

### live_overlay_cues

Stores active overlay cues for OBS browser sources.

Fields:
- id
- event_id
- cue_type
- cue_payload
- active
- created_at
- expires_at

### live_polls

Stores active live poll prompts.

Fields:
- id
- event_id
- round_id
- question
- options
- status
- opens_at
- closes_at

### live_poll_votes

Stores viewer votes for poll options.

Fields:
- id
- poll_id
- user_id
- option_key
- created_at

### stream_health_checks

Stores stream production health notes.

Fields:
- id
- event_id
- platform
- status
- bitrate
- dropped_frames
- notes
- created_at

---

## Overlay Browser Routes

Overlay pages should read from Supabase and subscribe to realtime updates.

Recommended routes:

```text
/overlay/main
/overlay/countdown
/overlay/poll
/overlay/leaderboard
/overlay/badge-unlock
/overlay/secret-vault
/overlay/analytics
/overlay/lower-third
```

---

## Admin Control Panel

Route:

```text
/admin/live-control
```

Admin controls:

- set active round
- open predictions
- lock predictions
- reveal actual results
- trigger scoring
- trigger badge unlock overlay
- trigger leaderboard overlay
- trigger Secret Vault reveal
- trigger poll
- cue confessional clip
- mark stream live/ended

---

## Security Notes

Use Row Level Security.

Public viewers may read:
- active events
- contestants
- songs
- leaderboard
- badges
- public overlay state

Authenticated users may:
- create predictions
- read their own predictions
- update their own unlocked predictions
- read their own badges

Only admins/service role should:
- reveal Secret 10
- write actual results
- trigger scoring
- update leaderboard snapshots
- trigger overlay cues
- modify event state

---

## Edge Function Opportunities

Create Supabase Edge Functions for:

- `lock_predictions`
- `score_round`
- `award_badges`
- `publish_leaderboard_snapshot`
- `trigger_overlay_cue`
- `close_poll`
- `calculate_poll_results`

This prevents client-side tampering and keeps scoring trusted.
