# Patch: OBS Go-Live Path for Songs 4 Survival by HAI

## Patch Purpose

This patch establishes a clear production path for **Songs 4 Survival by HAI** to go live on:

- Twitch
- Maestro.tv
- YouTube Live

using **OBS Studio** as the central broadcast software and **Supabase** as the backend for predictions, scoring, badges, leaderboards, contestant data, and live show state.

---

## Patch Contents

```text
docs/live-streaming/
├── OBS_GO_LIVE_GUIDE.md
├── STREAM_ARCHITECTURE.md
├── TECHNICAL_RUNBOOK.md
├── platforms/
│   ├── TWITCH_SETUP.md
│   ├── MAESTRO_TV_SETUP.md
│   └── YOUTUBE_SETUP.md
├── checklists/
│   ├── PRE_SHOW_CHECKLIST.md
│   ├── LIVE_SHOW_CHECKLIST.md
│   └── POST_SHOW_CHECKLIST.md
└── obs-scenes/
    └── OBS_SCENE_COLLECTION_SPEC.md

docs/backend/
└── SUPABASE_LIVE_BACKEND_PLAN.md

supabase/migrations/
└── 002_live_streaming_patch.sql

src/lib/
└── liveScoring.js

src/data/
└── obs-scene-map.json
```

---

## How to Apply This Patch

Copy the folders and files in this patch into the root of the existing GitHub repository.

If your repo already has matching folders, merge them.

Then apply the SQL migration:

```bash
supabase db push
```

or paste the migration contents into Supabase SQL Editor.

---

## Production Goal

The goal is to support a live production workflow where:

1. OBS handles the live broadcast.
2. Supabase handles live data.
3. Website/dashboard overlays render browser sources inside OBS.
4. Twitch/YouTube/Maestro receive the stream.
5. Viewers make predictions.
6. Predictions lock when the round timer expires.
7. Scoring updates automatically.
8. Badges unlock.
9. Leaderboards update in realtime.
10. Clips and recaps are created after the show.
