-- Songs 4 Survival by HAI
-- OBS / Live Streaming / Supabase patch

create table if not exists public.livestreams (
  id uuid primary key default uuid_generate_v4(),
  event_id uuid references public.events(id) on delete cascade,
  platform text not null,
  stream_url text,
  embed_url text,
  status text not null default 'scheduled',
  starts_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.live_overlay_cues (
  id uuid primary key default uuid_generate_v4(),
  event_id uuid references public.events(id) on delete cascade,
  cue_type text not null,
  cue_payload jsonb default '{}'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  expires_at timestamptz
);

create table if not exists public.live_polls (
  id uuid primary key default uuid_generate_v4(),
  event_id uuid references public.events(id) on delete cascade,
  round_id uuid references public.game_rounds(id) on delete set null,
  question text not null,
  options jsonb not null default '[]'::jsonb,
  status text not null default 'draft',
  opens_at timestamptz,
  closes_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.live_poll_votes (
  id uuid primary key default uuid_generate_v4(),
  poll_id uuid references public.live_polls(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  option_key text not null,
  created_at timestamptz not null default now(),
  unique (poll_id, user_id)
);

create table if not exists public.stream_health_checks (
  id uuid primary key default uuid_generate_v4(),
  event_id uuid references public.events(id) on delete cascade,
  platform text,
  status text not null default 'unknown',
  bitrate integer,
  dropped_frames integer,
  notes text,
  created_at timestamptz not null default now()
);

alter table public.livestreams enable row level security;
alter table public.live_overlay_cues enable row level security;
alter table public.live_polls enable row level security;
alter table public.live_poll_votes enable row level security;
alter table public.stream_health_checks enable row level security;

create policy "Public can read livestreams"
on public.livestreams for select using (true);

create policy "Public can read active overlay cues"
on public.live_overlay_cues for select using (active = true);

create policy "Public can read live polls"
on public.live_polls for select using (true);

create policy "Users can insert own poll votes"
on public.live_poll_votes for insert with check (auth.uid() = user_id);

create policy "Users can read own poll votes"
on public.live_poll_votes for select using (auth.uid() = user_id);

-- Stream health is production/admin-facing by default.
-- Add admin policies later based on HomelandAI role model.
